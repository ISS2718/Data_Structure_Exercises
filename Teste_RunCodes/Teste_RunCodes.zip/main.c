#include "stdio.h"
#include "stdlib.h"

int main()
{   
    FILE *Arq;
    int valor;
    char linha1[256];
    char linha2[256];

    Arq=fopen("arq.txt","rt");
    if (Arq==NULL) { 
        printf("ERRO!\n");
        exit(1); 
    }

    fgets(linha1,255,Arq);
    fgets(linha2,255,Arq);
    
    fclose(Arq);

    scanf("%d",&valor);
    if (valor == 1) {
        printf("%s",linha1);
    }
    else
    if (valor == 2) {
        printf("%s",linha2);
    }
    else
        printf("Entrada Invalida\n");

    return 0;
}
